package com.neu.dao;

public class PersonsDAO {

}
