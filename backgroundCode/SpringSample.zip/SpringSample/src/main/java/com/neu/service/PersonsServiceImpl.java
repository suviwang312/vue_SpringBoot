package com.neu.service;

import java.util.List;

import com.neu.vo.PersonsVO;

public class PersonsServiceImpl implements PersonsService{

	public List<PersonsVO> getPersonList(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
